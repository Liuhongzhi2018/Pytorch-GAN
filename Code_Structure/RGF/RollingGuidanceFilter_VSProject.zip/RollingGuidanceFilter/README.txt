
Distribution code Version 1.0 -- 08/14/2014 by Qi Zhang Copyright 2014, The Chinese University of Hong Kong.

The Code is created based on the method described in the following paper 
[1] "Rolling Guidance Filter", Qi Zhang, Xiaoyong Shen, Li Xu, Jiaya Jia, European Conference on Computer Vision (ECCV) 2014

The code includes the bilateral filter implementation of:
[2] "Fast High-Dimensional Filtering Using the Permutohedral Lattice", Adams, Andrew, Jongmin Baek, and Myers Abraham Davis, Computer Graphics Forum. Vol. 29. No. 2. Blackwell Publishing Ltd, 2010.

The code and the algorithm are for non-comercial use only.

********* IMPORTANT NOTE ********

PLEASE use the code in visual studio 2010/2012, Release Win32 Mode. (We only provide the openCV .lib/.dll files for this mode).



